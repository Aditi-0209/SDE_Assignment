import requests

# Get user input for the VIN
vin = input("Enter a valid VIN: ")

# Define the URL for the NHTSA API request
url = f"https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json"

# Make the API request
response = requests.get(url)

# Check if the response was successful
if response.status_code == 200:
    data = response.json()
    
    # Initialize default values
    vehicle_details = {
        'manufacturer': 'N/A',
        'model': 'N/A',
        'year': 'N/A'
    }
    
    # Extract vehicle details from the API response
    for result in data.get('Results', []):
        variable = result.get('Variable')
        value = result.get('Value')
        
        if variable == 'Make':
            vehicle_details['manufacturer'] = value
        elif variable == 'Model':
            vehicle_details['model'] = value
        elif variable == 'Model Year':
            vehicle_details['year'] = value
    
    # Print the extracted vehicle details
    print(vehicle_details)
else:
    print(f"Error: {response.status_code}")
